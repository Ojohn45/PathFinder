module pathfinder

go 1.26.0

require golang.org/x/crypto v0.57.0

require github.com/lib/pq v1.12.3

require golang.org/x/image v0.48.0
